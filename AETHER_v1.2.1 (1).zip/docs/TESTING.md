# Testing status and checklist

The checks below are a **manual test plan**, not a claim that every item has passed. The included Playwright scripts require the `playwright` package and a local browser installation; they cannot run in a clean Node.js environment without those dependencies.

## Manual smoke test

1. Serve the repository over localhost or HTTPS and open `index.html`.
2. Confirm the safety notice appears; accept it and verify the overview loads.
3. Open each view: Overview, Crew Health, Space Environment, Health Intelligence, Measurement Guide, Assistant, NASA Updates, Body Explorer, Mission Routine, Medical and Sources/Method.
4. Run the demo scenario and confirm the resulting entry is labeled **DEMO SCENARIO** and synthetic context is not described as live telemetry.
5. Submit a manual check-in and confirm it is labeled **MANUAL ENTRY** and persists after reload.
6. Switch environment profiles and confirm the selected profile is reflected in the interface.
7. Switch to Medical view, acknowledge an item and confirm the action appears in the local audit trail.
8. Export JSON and CSV; verify the files identify simulated/manual data. Test print-to-PDF.
9. Disconnect the network, reload after the app shell has been cached, and verify the local interface remains available. Confirm no message claims health records were synchronized to a server.
10. Test at desktop and narrow mobile widths; inspect keyboard focus and reduced-motion behavior.
11. In NASA Updates, verify unavailable feeds are clearly reported rather than replaced with fabricated live results.
12. If testing the optional external AI connection, use non-sensitive test prompts and verify the configured provider behavior.

## Automated checks

- `docs/SUBMISSION.md` — challenge-facing project summary and demo sequence.
- `tests/static.mjs` — dependency-free checks for inline JavaScript syntax, service-worker syntax, manifest JSON, icon and offline-shell assets, and visible prototype limitations. Run with `node tests/static.mjs`. This check is also configured in GitHub Actions.
- `tests/smoke.js` — browser navigation, demo scenario, service-worker and viewport smoke checks.
- `tests/assistant.js` — assistant response and mocked optional-provider checks.

Run only after installing Playwright and its browser binary, and serving the app locally. The static validation is not a browser test. A passing syntax check alone does not establish browser, clinical, security or mission readiness.

## Known limitations

- No clinical validation or astronaut usability study.
- No real crew telemetry, cabin sensor, wearable or radiation-dosimeter connection.
- No secure remote account, server storage or health-record synchronization.
- NASA public APIs may be unavailable, rate-limited or change their response format.
