# AETHER — NASA Space Apps project submission brief

**Challenge:** Create Health Monitoring Software for Astronauts on Space Missions  
**Team:** The Solo Challenger  
**Project:** AETHER — Astronaut Health Evaluation, Tracking & Early Response

## Short description

AETHER is an offline-capable astronaut-health decision-support prototype that brings crew-entered check-ins, illustrative health trends and public NASA space-weather context into one interface. It is designed to help a crew member or medical officer review patterns, see the evidence and limitations behind each insight, and prepare a clearer handoff to the flight medical team.

## The problem

During long-duration and deep-space missions, crews operate in a constrained environment and cannot assume immediate access to ground-based medical support. A single measurement can be difficult to interpret without its recent trend, the mission environment and the uncertainty around the data.

## The approach

AETHER demonstrates four connected ideas:

1. **Crew check-ins:** manually entered observations alongside clearly labelled synthetic sample readings.
2. **Trend and context review:** transparent comparisons against a generated demonstration baseline, with related indicators and simulated cabin context shown together.
3. **Evidence-aware explanations:** each insight exposes its confidence, limitations and relevant NASA human-spaceflight references.
4. **Offline-first access:** the interface and locally stored entries remain available without a continuous connection; the current prototype does not synchronize health records to a server.

NASA DONKI contributes public solar and space-weather event context only. It is not an onboard radiation dosimeter and does not report the dose received by a crew member inside a spacecraft.

## What is innovative in this prototype

AETHER does not present a single unexplained readiness score or treat every out-of-range reading as a diagnosis. It combines multiple signals, mission context, evidence links and explicit uncertainty in a single crew/medical workflow. The interface also distinguishes synthetic demo data, manual entries and public NASA information so reviewers can see where each value comes from.

## Current status and limitations

This is a working software concept for demonstration, not a flight-qualified system. Crew and cabin sample values are synthetic; check-ins are manually entered; thresholds are illustrative; and the logic has not been clinically validated. There are no live wearable, spacecraft environmental, onboard dosimeter or authenticated multi-user integrations. AETHER is not a medical device, is not approved or endorsed by NASA, and must not be used for real medical decisions.

## Suggested live demo

1. Open the project and acknowledge the safety/limitations notice.
2. Show the Mission Overview and identify the synthetic crew data and trend-alignment indicator.
3. Run the demo scenario to show how a sleep change and simulated cabin context appear together.
4. Open Health Intelligence and show the explanation, confidence, evidence and limitations.
5. Open Space Environment and explain that DONKI is public space-weather context, not onboard dose.
6. Finish with the offline/privacy view and the next-step roadmap.

## Next research steps

Validate the concept with spaceflight medical and human-factors specialists; evaluate curated NASA OSDR datasets with documented provenance; define validated measurement and alert requirements; and design secure, delay-tolerant data exchange before considering operational use.
