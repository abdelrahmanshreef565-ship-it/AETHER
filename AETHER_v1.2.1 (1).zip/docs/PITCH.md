# AETHER — 3-minute NASA Space Apps pitch

**0:00 — Hook**  
On a deep-space mission, medical support cannot always respond instantly. Communication delay between Earth and Mars changes with the planets' positions and can reach many minutes one way. Crew members need tools that help them notice patterns, understand context and communicate clearly with their medical team.

**0:25 — The challenge**  
Spaceflight exposes crews to interconnected hazards: radiation, isolation and confinement, distance from Earth, altered gravity, and hostile or closed environments. A single health reading rarely tells the whole story.

**0:50 — Our concept**  
AETHER brings crew-entered health observations, synthetic sample trends and mission-environment context into one offline-capable interface. Instead of presenting a number alone, it shows how a reading compares with a demonstration baseline, what other signals changed, what the system cannot conclude, and which NASA reference is relevant.

**1:20 — Live demonstration**  
Open Mission Overview and point out the seven indicators. Then select **Run demo scenario**. The scenario adds synthetic sleep and cabin-CO₂ changes. Show how AETHER surfaces the pattern, its confidence and limitations, and a suggested next check. Emphasize that the scenario is simulated—not a real crew alert.

**2:00 — Designed around a mission**  
Switch between spacecraft, station, rover and surface-base contexts. Show the Measurement Guide, the crew/medical views, local audit trail, export options and offline behavior. Explain that NASA DONKI contributes public space-weather context only; it does not measure radiation dose inside a spacecraft.

**2:35 — Evidence and honesty**  
Crew and cabin values in this prototype are synthetic; check-ins are manually entered; NASA feeds are public data when reachable. The baseline rules are illustrative and not clinically validated. AETHER is a research prototype and not a medical device, NASA-approved system or operational flight tool.

**2:50 — Close**  
Our next step is not to claim that the prototype is flight-ready. It is to validate the concept with human-spaceflight medical experts, integrate properly governed research data and real sensor interfaces, and test it rigorously. AETHER is a step toward making health information more contextual, transparent and useful when distance matters.
