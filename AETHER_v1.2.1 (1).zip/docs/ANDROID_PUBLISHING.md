# Publishing AETHER on Google Play (step by step)

AETHER is a Progressive Web App (installable, offline). Google Play accepts it as an Android app via a **Trusted Web Activity (TWA)**.

## 0. What I could not do for you
I cannot create your Google Play developer account, host the site, or sign the app. Those need your identity and payment. Everything else is prepared here.

## 1. Host the web app over HTTPS
Upload the contents of this folder to any HTTPS host (GitHub Pages, Netlify, Cloudflare Pages). Keep `.well-known/assetlinks.json` at the site root. Check the site opens, installs from Chrome ("Install app"), and works in airplane mode. If hosted in a subfolder, update `id`, `start_url` and `scope` in `manifest.webmanifest`.

## 2. Create the Android package
Easiest: https://www.pwabuilder.com → enter your URL → *Package for stores* → Android. Choose a package id such as `com.yourname.aether`, let it generate a signing key and **save the key and passwords safely** (losing it blocks future updates). Download the `.aab`.
(Alternative: `npm i -g @bubblewrap/cli` → `bubblewrap init --manifest https://YOUR_URL/manifest.webmanifest` → `bubblewrap build`.)

## 3. Link the site to the app
Put your signing key's SHA-256 fingerprint and package id in `.well-known/assetlinks.json` (PWABuilder shows it), redeploy, and confirm it loads at `https://YOUR_DOMAIN/.well-known/assetlinks.json`. Without this the app shows a browser address bar.

## 4. Google Play Console
1. Register a developer account (one-time fee, identity verification). New personal accounts must run a **closed test with at least 12 testers for 14 days** before production access. Check the current requirement in Play Console.
2. Create app → upload `.aab` to Internal testing first.
3. Store listing: use `PLAY_STORE_LISTING.md`. Upload icon (512×512), a 1024×500 feature graphic, and 2–8 phone screenshots (take them from the running app).
4. Privacy policy URL: host `privacy.html` and paste the link. Put your real support email in it first.
5. **App content → Health apps declaration**: declare it as a health/wellness app. State that it is not a medical device and does not diagnose. Check which health category and regulatory fields apply to you.
6. Data safety form: health entries never leave the device. Declare honestly that the app makes network requests to NASA (no personal data) and, **if the user enables the optional AI provider, sends user-typed questions (and readings only if the user opts in) to a third party**. Re-check Play's current data-safety wording for optional, user-initiated sharing.
7. Content rating questionnaire, target audience 18+, ads: none.

## 5. Before saying "for all astronauts"
Be accurate in the store text: this is an independent prototype created for a NASA challenge, not an official NASA or agency tool, and nobody should rely on it for clinical decisions. Agencies run their own approved medical systems. Real adoption would need clinical validation and partnership.

## 6. Production readiness checklist
- [ ] Real support email and domain in `privacy.html`
- [ ] Authenticated flight-surgeon accounts (the Medical role has no login in v1.0)
- [ ] Clinically reviewed reference ranges and alert rules
- [ ] Translations (Arabic, Spanish, French, Russian, Japanese, Chinese)
- [ ] Accessibility audit with screen readers
- [ ] Replace simulated baseline with real pre-flight data input

## 7. Keeping content up to date
- **Live in the app:** NASA Updates and the assistant refresh from NASA NTRS / Image Library / DONKI whenever the device is online (cached for 6 h).
- **Server-side snapshot:** push this folder to GitHub; `.github/workflows/update-feed.yml` runs daily, runs `tools/update_feed.mjs`, and commits a fresh `feed-snapshot.json`. Every installed app picks it up with no Play update, because the service worker fetches `feed-snapshot.json` and `knowledge.json` network-first.
- **Curated content:** edit `knowledge.json` (`entries`: `{id,title,tags,text,src}`) when NASA publishes new guidance. Bump `version`/`updated`. Have a clinician review changes.
- **Never auto-publish medical rules:** feed items are unreviewed search results; the alert thresholds only change through a reviewed release.

## 8. The AI assistant in production
For many users, do **not** ship an API key. Deploy a small proxy (Cloudflare Worker / Cloud Run) that holds the key, rate-limits, and strips identifiers; put its URL in the Assistant "Endpoint" setting or as the default in code. Keep the offline knowledge base as the fallback, and keep the emergency triage rule active.
