# Changelog

## 1.2.0 — 15 November 2026

- Clarified throughout the interface that crew and cabin values are synthetic demo data and that the comparison baseline is generated sample data, not a personal clinical baseline.
- Renamed the overview ring from “Readiness” to “Trend Alignment” and disclosed that its score is illustrative, not medical readiness.
- Corrected offline behavior messaging: entries remain local; this build has no server synchronization. Reconnection no longer falsely marks entries as synced.
- Expanded privacy disclosures for NASA public-data requests, locally stored API keys, and optional external AI prompts/context.
- Rewrote the privacy policy to match the current implementation and removed the placeholder support email.
- Corrected the pitch's Mars communication-delay line so it no longer presents a fixed delay as universal.
- Updated README, pitch and testing documentation to separate implemented features from roadmap items and unverified tests.
- Bumped the service-worker cache version and made the PWA manifest identity relative so the app can be hosted under a project subpath such as GitHub Pages.

## Validation performed

- JavaScript syntax check: passed.
- Service-worker JavaScript syntax check: passed.
- PWA manifest JSON parse: passed.
- Full Playwright browser suite: not run because Playwright is not installed in this environment.


## 1.2.1 — 15 November 2026

- Added a dependency-free static validation suite for application JavaScript, service-worker syntax, PWA manifest, required offline assets and visible prototype limitations.
- Added a GitHub Actions workflow to run static validation on pushes and pull requests.
- Added a challenge submission brief with a copy-ready project summary, honest innovation framing and demo sequence.
- Clarified the difference between static validation and browser/clinical/operational testing.
