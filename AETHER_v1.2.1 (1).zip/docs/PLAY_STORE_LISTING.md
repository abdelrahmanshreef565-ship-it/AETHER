# Google Play listing — draft only; not ready to publish

**App name:** AETHER: Astronaut Health  
**Short description:** An astronaut health decision-support concept prototype.

## Full description

AETHER is a demonstration interface exploring how health observations, sample trends and mission-environment context could be presented to a spaceflight crew.

- Daily check-in for heart rate, blood pressure, glucose, temperature, sleep, mood and exercise.
- Visual comparison against a synthetic demonstration baseline and broad illustrative reference bands.
- Contextual insights that combine multiple sample indicators with simulated cabin context.
- Measurement guide and NASA human-spaceflight hazard references.
- Spacecraft, space station, rover and lunar/Mars surface environment profiles.
- Crew and Medical demonstration views with local review acknowledgements and audit history.
- Local JSON/CSV export and print-to-PDF.
- Offline-capable app interface; public NASA feeds require an internet connection.
- Optional external AI assistant connection, disabled by default.

## Mandatory disclosure

This is a research/demo prototype, not a medical device. It does not diagnose or treat. Crew and cabin values are synthetic, check-ins are manually entered, and comparison baselines and alert thresholds are illustrative—not clinically validated. There is no real sensor integration, secure multi-user access or server-side health-record synchronization. NASA DONKI is used only for public space-weather context, not onboard radiation-dose measurement. AETHER is not affiliated with or endorsed by NASA or any space agency.

**Publishing status:** Do not submit this listing to an app store until the product, privacy, security, accessibility and clinical-safety requirements have been independently reviewed.
