// Node 18+. Run by the daily GitHub Action (or by hand): node tools/update_feed.mjs
// Fetches recent NASA items server-side so every installed app gets fresh content even if its device cannot reach NASA directly.
import {writeFileSync} from 'node:fs';
const strip=s=>String(s||'').replace(/<[^>]+>/g,'');
const items=[];
try{
  const r=await fetch('https://ntrs.nasa.gov/api/citations/search?q='+encodeURIComponent('spaceflight astronaut health')+'&page.size=30');
  const j=await r.json();
  for(const x of (j.results||j.hits||[]))items.push({k:'research',title:strip(x.title),summary:strip(x.abstract),date:x.distributionDate||x.created||'',url:'https://ntrs.nasa.gov/citations/'+x.id,src:'NASA NTRS'});
}catch(e){console.error('NTRS failed',e.message)}
try{
  const r=await fetch('https://images-api.nasa.gov/search?q='+encodeURIComponent('astronaut health exercise')+'&media_type=image&page_size=15');
  const j=await r.json();
  for(const x of (j.collection?.items||[])){const d=x.data?.[0]||{};items.push({k:'media',title:d.title||'',summary:d.description||'',date:d.date_created||'',url:'https://images.nasa.gov/details/'+d.nasa_id,src:'NASA Image Library'})}
}catch(e){console.error('Images failed',e.message)}
items.sort((a,b)=>(b.date||'').localeCompare(a.date||''));
if(!items.length){console.error('No items fetched; keeping existing snapshot.');process.exit(0)}
writeFileSync('feed-snapshot.json',JSON.stringify({updated:new Date().toISOString().slice(0,10),items:items.filter(i=>i.title).slice(0,40)},null,1));
console.log('Wrote',items.length,'items');
