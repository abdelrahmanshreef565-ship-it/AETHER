const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch(),p=await b.newPage({viewport:{width:1280,height:850}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.route('https://api.anthropic.com/**',r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({content:[{type:'text',text:'Mock LLM answer about sleep.'}]})}));
await p.goto('http://localhost:8080/index.html');await p.check('#gateck');await p.click('#gatebtn');
await p.evaluate(()=>{S.feed={t:Date.now(),status:{ntrs:'live'},items:[{k:'research',title:'Countermeasures for bone loss on long missions',summary:'New resistive exercise study',date:'2026-10-01',url:'https://ntrs.nasa.gov/citations/1',src:'NASA NTRS'}]};save();go('assistant')});
const qs=['I have chest pain','How am I doing today?','Why does sleep matter in space?','what is SANS','tell me about pizza recipes',"what's new from NASA?",'my pulse is high what should i do'];
for(const q of qs){await p.evaluate(q=>ask(q),q);await p.waitForTimeout(50);const last=await p.evaluate(()=>CHAT[CHAT.length-1].t);console.log('Q:',q,'\n  A:',last.replace(/\n/g,' | ').slice(0,170))}
await p.screenshot({path:'assistant-chat.png'});
await p.evaluate(()=>{S.llm={provider:'anthropic',endpoint:'',key:'sk-test',model:'',share:true};});
await p.evaluate(()=>ask('Why is sleep important?'));await p.waitForTimeout(300);
console.log('LLM:',await p.evaluate(()=>CHAT[CHAT.length-1].t),await p.evaluate(()=>CHAT[CHAT.length-1].llm));
await p.evaluate(()=>go('updates'));await p.screenshot({path:'assistant-updates.png'});
console.log('errors',errs);await b.close()})()
