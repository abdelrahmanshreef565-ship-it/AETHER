// Run: serve folder (python3 -m http.server 8080) then: node tests/smoke.js
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch(),p=await b.newPage({viewport:{width:1280,height:800}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('http://localhost:8080/index.html');
console.log('gate visible:',await p.isVisible('#gate'));
await p.check('#gateck');await p.click('#gatebtn');
for(const v of ['overview','health','env','intel','guide','body','routine','med','about','settings']){await p.evaluate(v=>go(v),v);}
await p.evaluate(()=>{go('overview');runScenario()});
console.log('levels:',await p.evaluate(()=>CREW.map(c=>analyze(c.id).level)));
await p.evaluate(()=>go('overview'));await p.screenshot({path:process.argv[2]||'shot.png'});
const m=await p.evaluate(()=>fetch('manifest.webmanifest').then(r=>r.json()));console.log('manifest:',m.name);
await p.waitForTimeout(1200);console.log('sw controller:',await p.evaluate(()=>navigator.serviceWorker.getRegistration().then(r=>!!r)));
await p.setViewportSize({width:390,height:800});await p.evaluate(()=>go('health'));await p.screenshot({path:(process.argv[2]||'shot.png').replace('.png','-m.png')});
console.log('errors:',errs);await b.close()})()
