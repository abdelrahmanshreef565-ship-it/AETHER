// Dependency-free static validation for AETHER.
// Run: node tests/static.mjs
import {readFileSync, existsSync} from 'node:fs';
import {Script} from 'node:vm';
import assert from 'node:assert/strict';

const read = p => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const html = read('index.html');
const manifest = JSON.parse(read('manifest.webmanifest'));
const checks = [];
const check = (name, fn) => { fn(); checks.push(name); };

check('main HTML document and viewport metadata', () => {
  assert.match(html, /<!doctype html>/i);
  assert.match(html, /name="viewport"/i);
  assert.match(html, /<title>AETHER/);
  assert.match(html, /const APP_VERSION='1\.2\.1'/);
});
check('inline application JavaScript parses', () => {
  const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
  assert.ok(scripts.length > 0, 'no inline application script found');
  for (const script of scripts) new Script(script[1]);
});
check('service worker JavaScript parses', () => new Script(read('sw.js')));
check('PWA manifest has a relative identity and valid icons', () => {
  assert.ok(manifest.name && manifest.short_name);
  assert.equal(manifest.start_url, './index.html');
  assert.equal(manifest.scope, './');
  assert.ok(manifest.id.startsWith('./'));
  for (const icon of manifest.icons) assert.ok(existsSync(new URL(`../${icon.src}`, import.meta.url)), `missing icon ${icon.src}`);
});
check('service worker shell assets exist', () => {
  const sw = read('sw.js');
  const match = sw.match(/SHELL\s*=\s*\[([\s\S]*?)\]/);
  assert.ok(match, 'SHELL cache list not found');
  const paths = [...match[1].matchAll(/'([^']+)'/g)].map(m => m[1]).filter(p => p !== './');
  for (const path of paths) assert.ok(existsSync(new URL(`../${path}`, import.meta.url)), `missing shell asset ${path}`);
});
check('prototype limitations are visible in the app', () => {
  assert.match(html, /synthetic demo baseline/i);
  assert.match(html, /not a diagnostic tool/i);
  assert.match(html, /not(?:<\/b>)? the on-board dose measurement/i);
  assert.match(html, /does not upload or synchronize health records/i);
});
check('privacy policy and project documentation exist', () => {
  for (const p of ['privacy.html','README.md','docs/PITCH.md','docs/TESTING.md'])
    assert.ok(existsSync(new URL(`../${p}`, import.meta.url)), `missing ${p}`);
});
check('NASA snapshot is valid JSON', () => {
  const feed = JSON.parse(read('feed-snapshot.json'));
  assert.ok(feed && typeof feed === 'object');
  assert.ok(Array.isArray(feed.items));
});

console.log(`AETHER static validation: ${checks.length}/${checks.length} checks passed`);
for (const name of checks) console.log(`PASS  ${name}`);
